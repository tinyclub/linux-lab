/* fix-nop.c
 * Heihaier - admin@heihaier.org
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <elf.h>

#define INSN_ORIG		0x00000000
#define INSN_FIXED		0x00200825	/* or at,at,zero */

void fix_nop_32(void *p)
{
	Elf32_Half i;

	Elf32_Ehdr *elf32_ehdr = p;
	Elf32_Shdr *elf32_shdrs = (Elf32_Shdr *) (p + elf32_ehdr->e_shoff);

	for (i = 0; i < elf32_ehdr->e_shnum; i++) {
		if (elf32_shdrs[i].sh_flags & SHF_EXECINSTR) {
			unsigned int *insn =
			    (unsigned int *)(p + elf32_shdrs[i].sh_offset);
			Elf32_Word n, size =
			    elf32_shdrs[i].sh_size / sizeof(unsigned int);

			for (n = 0; n < size; n++) {
				if (INSN_ORIG == insn[n]) {
					insn[n] = INSN_FIXED;
				}
			}
		}
	}
}

void fix_nop_64(void *p)
{
	Elf64_Half i;

	Elf64_Ehdr *elf64_ehdr = p;
	Elf64_Shdr *elf64_shdrs = (Elf64_Shdr *) (p + elf64_ehdr->e_shoff);

	for (i = 0; i < elf64_ehdr->e_shnum; i++) {
		if (elf64_shdrs[i].sh_flags & SHF_EXECINSTR) {
			unsigned int *insn =
			    (unsigned int *)(p + elf64_shdrs[i].sh_offset);
			Elf64_Word n, size =
			    elf64_shdrs[i].sh_size / sizeof(unsigned int);

			for (n = 0; n < size; n++) {
				if (INSN_ORIG == insn[n]) {
					insn[n] = INSN_FIXED;
				}
			}
		}
	}
}

int main(int argc, char *argv[])
{
	int elf_file;
	struct stat sb;

	if (2 != argc) {
		printf("Usage: fix-nop elf_file\n");
		return -1;
	}

	elf_file = open(argv[1], O_RDWR);
	if (-1 == elf_file) {
		printf("ERROR: open %s failed!\n", argv[1]);
		return -1;
	}

	fstat(elf_file, &sb);
	void *p = mmap(NULL, sb.st_size, PROT_READ | PROT_WRITE, MAP_PRIVATE,
		       elf_file, 0);
	if (MAP_FAILED == p) {
		printf("ERROR: mmap failed!\n");
		return -1;
	}

	if ((((unsigned char *)p)[EI_MAG0] != ELFMAG0) ||
	    (((unsigned char *)p)[EI_MAG1] != ELFMAG1) ||
	    (((unsigned char *)p)[EI_MAG2] != ELFMAG2) ||
	    (((unsigned char *)p)[EI_MAG3] != ELFMAG3)) {
		printf("ERROR: %s isn't elf file.\n", argv[1]);
		return -1;
	}

	if (((unsigned char *)p)[EI_CLASS] == ELFCLASS32)
		fix_nop_32(p);
	else if (((unsigned char *)p)[EI_CLASS] == ELFCLASS64)
		fix_nop_64(p);

	if (write(elf_file, p, sb.st_size) != sb.st_size) {
		printf("ERROR: write failed!\n");
		return -1;
	}

	munmap(p, sb.st_size);
	close(elf_file);

	printf("INFO: fix %s success!\n", argv[1]);

	return 0;
}
